class Log < ActiveRecord::Base
  belongs_to :batch
end
