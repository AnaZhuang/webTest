# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Sister::Application.config.secret_token = 'e2c4ad1103330551610e7ab2d8502a8e46246e3c02a1c0d918b37a6733ad802284bd7874322ea187ac59aa66c6247e553d5056bdc9e7bb19408a0abfd3e04c87'
