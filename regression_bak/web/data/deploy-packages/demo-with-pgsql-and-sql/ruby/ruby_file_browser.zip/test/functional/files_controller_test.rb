require 'test_helper'

class FilesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
