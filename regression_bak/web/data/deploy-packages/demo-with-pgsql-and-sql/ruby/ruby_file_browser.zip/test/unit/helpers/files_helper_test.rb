require 'test_helper'

class FilesHelperTest < ActionView::TestCase
end
