# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
FileBrowser::Application.config.secret_token = '524ea41b49ddd0c15db04a31516602783b9e0e282671d1460f72a50c0cd77cd23b26fc2b2d052ad5ace2180f1ca479d31405a94437746f33df99218499301ce9'
