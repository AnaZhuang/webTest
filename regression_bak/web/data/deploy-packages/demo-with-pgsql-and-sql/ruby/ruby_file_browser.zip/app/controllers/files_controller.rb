require 'fileutils'
class FilesController < ApplicationController
  def index
    @path = File.expand_path("/#{params[:path]}")
    return(render_404) unless File.exist? @path
    unless File.directory?(@path)
      send_file @path
      return
    end
    @files = Dir.glob("#{@path}/*").map{|f|
      f.sub(@path + '/', '')
    }.sort
  end

  def root
    redirect_to '/files'
  end

  def env
    set = ENV.keys.sort.map{|k|
      "#{k}=#{ENV[k]}"
    }.join("<br/>")
    render :text => set
  end

  def long
    sleep 5*60
    render :text => 'this should not timeout'
  end

private
  def render_404
    render :text => "#{@path} dosen't exist!"
  end
end
