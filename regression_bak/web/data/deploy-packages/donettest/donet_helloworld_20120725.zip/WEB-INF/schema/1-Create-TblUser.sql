/*
 * Defines which web user belongs to which role.
 */

#@Package[org.onecloud.demo.filemanager.sql]
#@Persistence[database="filedb"]

CREATE TABLE TblUser
(
    UserID                          VARCHAR(20)     NOT NULL,
    UserPassword                    VARCHAR(20)     NOT NULL,
    UserName                        VARCHAR(50)     NOT NULL,
    UserMail                        VARCHAR(200)    NOT NULL,
    UserCreated                     DATE            NOT NULL,
    UserType                        INT             NOT NULL,
    PRIMARY KEY (UserID)
)DEFAULT CHARACTER SET UTF8;
