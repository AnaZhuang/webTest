﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class sell : System.Web.UI.Page
{
    SqlConnection myConn = new SqlConnection("server=SUDA-20110427HH;database=xinxi;user id=sa;pwd=123");

    SqlCommand myCmd = new SqlCommand();

    DataSet ds = new DataSet();

    SqlDataAdapter da = new SqlDataAdapter();


    protected void Page_Load(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;

        //cmd.CommandText = "proc1";    //存储过程
        //cmd.CommandType = CommandType.StoredProcedure;
        // cmd.Parameters.Add("@n", SqlDbType.Int, 10).Direction = ParameterDirection.Input;


        da.SelectCommand = myCmd;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;
        myCmd.CommandText = "";

        string mySQL = "";

        mySQL = "insert into sell(client_id,debtdate,money) values('";

        mySQL = mySQL + this.TextBox1.Text + "','" + this.Calendar1.SelectedDate.ToString() + "','" + this.TextBox2.Text + "')";
        myCmd.CommandText = mySQL;

        try
        {
            myConn.Open();
            myCmd.ExecuteNonQuery();
            Label1.Text = "插入成功！";
        }
        catch (Exception ex)
        {
            //Label1.Text= "插入失败！";
            Label1.Text = ex.ToString();

        }

        myConn.Close();

    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        string update = "update sell set client_id='" + this.TextBox1.Text + "'," + " debtdate='" + this.Calendar1.SelectedDate.ToString() + "'," + "money='" + this.TextBox2.Text + "'" + "where id='" + this.DropDownList1.SelectedValue.ToString() + "'";
        myCmd.CommandText = update;
        try
        {

            myConn.Open();
            myCmd.ExecuteNonQuery();
            Label1.Text = "修改成功！";
        }
        catch (Exception ex)
        {

            Label1.Text = ex.ToString();

        }
        myConn.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        string xianshi = "select * from sell";
        myCmd.CommandText = xianshi;
        myConn.Open();


        // cmd.Parameters[0].Value = int.Parse(this.TextBox1.Text);


        ds.Clear();

        da.Fill(ds);


        myConn.Close();


        this.GridView1.DataSource = ds.Tables[0];

        GridView1.DataBind();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
