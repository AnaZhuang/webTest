﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Xml.Linq;
using System.Web.Security;


public partial class client : System.Web.UI.Page
{

    SqlConnection myConn = new SqlConnection("server=SUDA-20110427HH;database=xinxi;user id=sa;pwd=123");

    SqlCommand myCmd = new SqlCommand();

    DataSet ds = new DataSet();

    SqlDataAdapter da = new SqlDataAdapter();


    protected void Page_Load(object sender, EventArgs e)
    {
        string mysql = "select * from area_info ";

        if (!IsPostBack)            //使页面只在第一次加载时执行该连接操作
        {

            myConn.Open();
            myCmd.Connection = myConn;
            myCmd.CommandText = mysql;

            da.SelectCommand = myCmd;
            da.Fill(ds);
            myConn.Close();

            DropDownList1.DataSource = ds.Tables[0];
            DropDownList1.DataTextField = ds.Tables[0].Columns["name"].ToString();
            DropDownList1.DataValueField = ds.Tables[0].Columns["area_id"].ToString();

            DropDownList1.DataBind();
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        string mySQL = "";

        mySQL = "insert into client_info (client_id,name,address,linkman,phone,area_id,debtdate,line_credit,payables,email) values('";

        mySQL = mySQL + this.TextBox1.Text.Trim() + "','" + this.TextBox2.Text.Trim() + "','" + this.TextBox3.Text.Trim() + "','" + this.TextBox4.Text.Trim() + "','" + this.TextBox5.Text.Trim() + "','" + this.DropDownList1.Text.Trim() + "','";

        mySQL = mySQL + this.Calendar1.SelectedDate.ToString() + "','"+ this.TextBox6.Text.Trim() + "','" + this.TextBox7.Text.Trim() + "','" + this.TextBox8.Text.Trim() + "')";

        myCmd.CommandText = mySQL;

        try
        {
            myConn.Open();
            myCmd.ExecuteNonQuery();
            Label1.Text= "插入成功！";
        }
        catch (Exception ex)
        {
            //Label1.Text= "插入失败！";
            Label1.Text = ex.ToString();

        }

        myConn.Close();


    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        string update = "update client_info set client_id='" + this.TextBox1.Text + "'," + " debtdate='" + this.Calendar1.SelectedDate.ToString() 
            + "'," + "name='" + this.TextBox2.Text + "'," + "address='" + this.TextBox3.Text + "'," + "linkman='" + this.TextBox4.Text + "',"
            + "phone='" + this.TextBox5.Text + "'," + "area_id='" + this.TextBox9.Text + "'," + "line_credit='" + this.TextBox6.Text + "',"
            + "payables='" + this.TextBox7.Text + "'," + "email='" + this.TextBox8.Text + "'" + "where client_id='" + this.DropDownList2.SelectedValue.ToString() + "'";
        myCmd.CommandText = update;
        try
        {

            myConn.Open();
            myCmd.ExecuteNonQuery();
            Label1.Text = "修改成功！";
        }
        catch (Exception ex)
        {

            Label1.Text = ex.ToString();

        }
        myConn.Close();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.TextBox9.Text = this.DropDownList1.SelectedValue.ToString();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;

        da.SelectCommand = myCmd;

        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        string xianshi = "select * from client_info";
        myCmd.CommandText = xianshi;
        myConn.Open();




        ds.Clear();

        da.Fill(ds);


        myConn.Close();


        this.GridView1.DataSource = ds.Tables[0];

        GridView1.DataBind();
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        string delete = "delete from client_info where client_id='" + this.DropDownList2.SelectedValue.ToString() + "'";

        myCmd.CommandText = delete;
        try
        {

            myConn.Open();
            myCmd.ExecuteNonQuery();
            Label1.Text = "删除成功！";
        }
        catch 
        {

            Label1.Text = "您所要删除的客户信息在黑名单中，无法删除，请确定信息！";

        }
        myConn.Close();
    }
}




  