﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{

    SqlConnection myConn = new SqlConnection("server=SUDA-20110427HH;database=xinxi;user id=sa;pwd=123");
    SqlCommand myCmd = new SqlCommand();
    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        string mysql = "select * from area_info ";

        if (!IsPostBack)            //使页面只在第一次加载时执行该连接操作
        {

            myConn.Open();
            myCmd.Connection = myConn;
            myCmd.CommandText = mysql;

            sda.SelectCommand = myCmd;
            sda.Fill(ds);
            myConn.Close();

            DropDownList1.DataSource = ds.Tables[0];
            DropDownList1.DataTextField = ds.Tables[0].Columns["name"].ToString();
            DropDownList1.DataValueField = ds.Tables[0].Columns["area_id"].ToString();

            DropDownList1.DataBind();
        }

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.TextBox3.Text = this.DropDownList1.SelectedValue.ToString();
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        string insert = "insert into area_info(name,area_id) values ('" + this.TextBox1.Text + "','" + this.TextBox2.Text + "')";
        myCmd.CommandText = insert;
        try
        {

            myConn.Open();
            myCmd.ExecuteNonQuery();
            Label1.Text = "插入成功！";
        }
        catch (Exception ex)
        {
            
            Label1.Text = ex.ToString();

        }
        myConn.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string update = "update area_info set area_id='" + this.TextBox2.Text + "',";
        update = update + "name=N'" + this.TextBox1.Text + "'" + "where area_id='" + this.TextBox3.Text + "'";
        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        myCmd.CommandText = update;
        try
        {

            myConn.Open();
            myCmd.ExecuteNonQuery();
            Label1.Text = "修改成功！";
        }
        catch (Exception ex)
        {
           
            Label1.Text = ex.ToString();

        }
        myConn.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        string delete = "delete from area_info where area_id='" + this.TextBox3.Text + "'";
        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        myCmd.CommandText = delete;
        try
        {

            myConn.Open();
            myCmd.ExecuteNonQuery();
            Label1.Text = "删除成功！";
        }
        catch (Exception ex)
        {
            
            Label1.Text = ex.ToString();

        }
        myConn.Close();
    }

}
