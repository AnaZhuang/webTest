﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class blacklist : System.Web.UI.Page
{
    SqlConnection myConn = new SqlConnection("server=SUDA-20110427HH;database=xinxi;user id=sa;pwd=123");

    SqlCommand myCmd = new SqlCommand();

    DataSet ds = new DataSet();

    SqlDataAdapter da = new SqlDataAdapter();


    protected void Page_Load(object sender, EventArgs e)
    {
       // myCmd.Connection = myConn;

        //myCmd.CommandText = "";    //存储过程
        myCmd.CommandType = CommandType.StoredProcedure;
        myCmd.Parameters.Add("@n", SqlDbType.Int, 10).Direction = ParameterDirection.Input;


        da.SelectCommand = myCmd;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        myCmd.Connection = myConn;
        myCmd.CommandText = "";
        string xianshi = this.RadioButtonList2.SelectedValue.ToString();
        myCmd.CommandText = xianshi;
        myConn.Open();


        myCmd.Parameters[0].Value = int.Parse(this.TextBox1.Text);


        ds.Clear();

        da.Fill(ds);


        myConn.Close();


        this.GridView1.DataSource = ds.Tables[0];

        GridView1.DataBind();
    }
}
