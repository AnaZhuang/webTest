﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Reimbursement : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("server=localhost;database=customer;user id=sa;pwd=123");
    SqlCommand cmd1 = new SqlCommand();
    SqlCommand cmd2 = new SqlCommand();

    SqlDataAdapter sda1 = new SqlDataAdapter();
    SqlDataAdapter sda2 = new SqlDataAdapter();

    DataSet ds1 = new DataSet();
    DataSet ds2 = new DataSet();


    string mysql1 = "select * from reimbursement";
    string mysql2 = "select * from reimbursement where tradingID='";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)            //使页面只在第一次加载时执行该连接操作
        {

            conn.Open();
            cmd1.Connection = conn;
            cmd1.CommandText = mysql1;

            sda1.SelectCommand = cmd1;
            sda1.Fill(ds1);
            conn.Close();

            DropDownList1.DataSource = ds1.Tables[0];
            DropDownList1.DataTextField = ds1.Tables[0].Columns["tradingID"].ToString();


            DropDownList1.DataBind();
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        mysql2 = mysql2 + DropDownList1.SelectedItem.ToString() + "'";

        conn.Open();
        cmd2.Connection = conn;
        cmd2.CommandText = mysql2;
        sda2.SelectCommand = cmd2;
        sda2.Fill(ds2);
        conn.Close();

        this.TextBox2.Text = this.ds2.Tables[0].Rows[0]["userID"].ToString();
        this.TextBox3.Text = this.ds2.Tables[0].Rows[0]["reim_time"].ToString();
        this.TextBox4.Text = this.ds2.Tables[0].Rows[0]["money_sum"].ToString();
        this.TextBox5.Text = this.ds2.Tables[0].Rows[0]["note"].ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string insert = "insert into reimbursement values('";
        insert = insert + this.TextBox2.Text + "','" + this.TextBox3.Text + "','";
        insert = insert + this.TextBox4.Text + "','" + this.TextBox5.Text + "')";

        cmd1.Connection = conn;
        cmd1.CommandText = insert;

        try
        {
            conn.Open();
            cmd1.ExecuteNonQuery();
            Label1.Text = "录入成功！！";
        }
        catch
        {
            Label1.Text = "录入失败，请查询无误后再录入！！";
        }
        finally
        {
            conn.Close();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string update = "update reimbursement set userID='" + this.TextBox2.Text + "',reim_time='" + this.TextBox3.Text;
        update = update + "',money_sum='" + this.TextBox4.Text + "',note='" + this.TextBox5.Text + "' where tradingID='";
        update = update + this.DropDownList1.SelectedItem.ToString() + "'";

        cmd1.Connection = conn;
        cmd1.CommandText = update;

        try
        {
            conn.Open();
            cmd1.ExecuteNonQuery();
            Label2.Text = "修改成功！！";
        }
        catch (Exception ex)
        {
            Response.Write(ex);
            Label2.Text = "修改失败，请查询无误后再修改！！";
        }
        finally
        {
            conn.Close();
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        string delete = "delete from reimbursement where tradingID='" + this.DropDownList1.SelectedItem.ToString() + "'";

        cmd1.Connection = conn;
        cmd1.CommandText = delete;

        try
        {
            conn.Open();
            cmd1.ExecuteNonQuery();
            Label3.Text = "删除成功！！";
        }
        catch (Exception ex)
        {
            Response.Write(ex);
            Label3.Text = "删除失败，请查询无误后再删除！！";
        }
        finally
        {
            conn.Close();
        }
    }
}
