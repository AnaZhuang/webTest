﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class CustomerInformatiom : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("server=localhost;database=customer;user id=sa;pwd=123");
    SqlCommand cmd1 = new SqlCommand();
    SqlCommand cmd2 = new SqlCommand();
    SqlCommand cmd3 = new SqlCommand();
    SqlDataAdapter sda = new SqlDataAdapter();
    SqlDataAdapter sda2 = new SqlDataAdapter();
    SqlDataAdapter sda3 = new SqlDataAdapter();
    DataSet ds = new DataSet();
    DataSet ds2 = new DataSet();
    DataSet ds3 = new DataSet();

    string mysql = "select * from customer_info";
    string mysql2 = "select * from District";
    string mysql3 = "select * from customer_info where userID='";


    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)            //使页面只在第一次加载时执行该连接操作
        {

            conn.Open();
            cmd1.Connection = conn;
            cmd1.CommandText = mysql;

            sda.SelectCommand = cmd1;
            sda.Fill(ds);
            conn.Close();

            DropDownList1.DataSource = ds.Tables[0];
            DropDownList1.DataTextField = ds.Tables[0].Columns["customerName"].ToString();
            DropDownList1.DataValueField = ds.Tables[0].Columns["userID"].ToString();

            DropDownList1.DataBind();


            conn.Open();
            cmd2.Connection = conn;
            cmd2.CommandText = mysql2;

            sda2.SelectCommand = cmd2;
            sda2.Fill(ds2);
            conn.Close();

            DropDownList2.DataSource = ds2.Tables[0];
            DropDownList2.DataTextField = ds2.Tables[0].Columns["DisName"].ToString();
            DropDownList2.DataValueField = ds2.Tables[0].Columns["DisID"].ToString();

            DropDownList2.DataBind();
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.TextBox1.Text = this.DropDownList1.SelectedValue.ToString();

        mysql3 = mysql3 + DropDownList1.SelectedValue.Trim() + "'";

        conn.Open();
        cmd3.Connection = conn;
        cmd3.CommandText = mysql3;

        sda3.SelectCommand = cmd3;
        sda3.Fill(ds3);
        conn.Close();

        this.TextBox2.Text = ds3.Tables[0].Rows[0]["customerName"].ToString();
        this.TextBox3.Text = ds3.Tables[0].Rows[0]["userID"].ToString();
        this.TextBox4.Text = ds3.Tables[0].Rows[0]["address"].ToString();
        this.TextBox5.Text = ds3.Tables[0].Rows[0]["contact"].ToString();
        this.TextBox6.Text = ds3.Tables[0].Rows[0]["telephone"].ToString();
        this.TextBox7.Text = ds3.Tables[0].Rows[0]["fax"].ToString();
        this.TextBox8.Text = ds3.Tables[0].Rows[0]["DisID"].ToString();
        this.TextBox12.Text = ds3.Tables[0].Rows[0]["reimbursement_Time"].ToString();
        this.TextBox9.Text = ds3.Tables[0].Rows[0]["credit"].ToString();
        this.TextBox10.Text = ds3.Tables[0].Rows[0]["accounts"].ToString();
        this.TextBox11.Text= ds3.Tables[0].Rows[0]["email"].ToString();
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.TextBox8.Text = this.DropDownList2.SelectedValue.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string insert = "insert into customer_info(customerName,userID,address,contact,telephone,fax,DisID,reimbursement_Time,credit,accounts,email) values('";
        insert = insert + this.TextBox2.Text.ToString() + "','" + this.TextBox3.Text.ToString() + "','" + this.TextBox4.Text.ToString() + "','";
        insert = insert + this.TextBox5.Text.ToString() + "','" + this.TextBox6.Text.ToString() + "','" + this.TextBox7.Text.ToString() + "','";
        insert = insert + this.TextBox8.Text.ToString() + "','" + this.TextBox12.Text.ToString() + "','" + this.TextBox9.Text.ToString() + "','";
        insert = insert + this.TextBox10.Text.ToString() + "','" + this.TextBox11.Text.ToString() + "')";
        cmd1.Connection = conn;
        cmd1.CommandText = "";
        cmd1.CommandText = insert;

        try
        {
            conn.Open();
            cmd1.ExecuteNonQuery();
            Label5.Text = "录入成功！！";
        }
        catch
        {
            Label5.Text = "录入失败，请查询无误后再录入！！";
        }
        finally
        {
            conn.Close();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string update = "update customer_info set customerName=N'" + this.TextBox2.Text.ToString() + "',";
        update = update + "userID='" + this.TextBox3.Text + "'," + "address='" + this.TextBox4.Text + "',";
        update = update + "contact='" + this.TextBox5.Text + "'," + "telephone='" + this.TextBox6.Text + "',";
        update = update + "fax='" + this.TextBox7.Text + "'," + "DisID='" + this.TextBox8.Text + "',";
        update = update + "credit='" + this.TextBox9.Text + "'," + "accounts='" + this.TextBox10.Text + "',";
        update = update + "reimbursement_Time='" + this.TextBox12.Text + "'," + "email='" + this.TextBox11.Text + "'";
        update = update + "where userID='" + this.TextBox1.Text + "'";

        cmd1.Connection = conn;
        cmd1.CommandText = "";
        cmd1.CommandText = update;

        try
        {
            conn.Open();
            cmd1.ExecuteNonQuery();
            Label6.Text = "修改成功！！";
        }
        catch (Exception ex)
        {
            Response.Write(ex);
            Label6.Text = "修改失败，请查询无误后再修改！！";
        }
        finally
        {
            conn.Close();
        }
    }
}
