﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Blacklist : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("server=localhost;database=customer;user id=sa;pwd=123");
    SqlDataAdapter sda1 = new SqlDataAdapter();
    SqlDataAdapter sda2 = new SqlDataAdapter();
    SqlCommand cmd1 = new SqlCommand();
    SqlCommand cmd2 = new SqlCommand();
    DataSet ds = new DataSet();


    protected void Page_Load(object sender, EventArgs e)
    {
        cmd1.Connection = conn;

        cmd1.CommandText = "proc_blacklist_1";    //存储过程
        cmd1.CommandType = CommandType.StoredProcedure;
        cmd1.Parameters.Add("@n", SqlDbType.Int, 10).Direction = ParameterDirection.Input;


        sda1.SelectCommand = cmd1;


        cmd2.Connection = conn;

        cmd2.CommandText = "proc_blacklist_2";    //存储过程
        cmd2.CommandType = CommandType.StoredProcedure;
        cmd2.Parameters.Add("@money", SqlDbType.Money, 10).Direction = ParameterDirection.Input;


        sda2.SelectCommand = cmd2;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        conn.Open();
        cmd1.Parameters[0].Value = int.Parse(this.TextBox1.Text);
        ds.Clear();
        sda1.Fill(ds);
        conn.Close();

        this.GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        conn.Open();
        cmd1.Parameters[0].Value = -int.Parse(this.TextBox1.Text);
        ds.Clear();
        sda1.Fill(ds);
        conn.Close();

        this.GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        conn.Open();
        cmd2.Parameters[0].Value = int.Parse(this.TextBox2.Text);
        ds.Clear();
        sda2.Fill(ds);
        conn.Close();

        this.GridView2.DataSource = ds.Tables[0];
        GridView2.DataBind();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        conn.Open();
        cmd2.Parameters[0].Value = -int.Parse(this.TextBox2.Text);
        ds.Clear();
        sda2.Fill(ds);
        conn.Close();

        this.GridView2.DataSource = ds.Tables[0];
        GridView2.DataBind();
    }

}
