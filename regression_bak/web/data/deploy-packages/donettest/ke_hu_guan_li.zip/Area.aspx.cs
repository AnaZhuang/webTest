﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class Area : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("server=localhost;database=customer;user id=sa;pwd=123");
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        
        string mysql = "select * from District ";

        if (!IsPostBack)            //使页面只在第一次加载时执行该连接操作
        {

            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = mysql;

            sda.SelectCommand = cmd;
            sda.Fill(ds);
            conn.Close();

            DropDownList1.DataSource = ds.Tables[0];
            DropDownList1.DataTextField = ds.Tables[0].Columns["disname"].ToString();
            DropDownList1.DataValueField = ds.Tables[0].Columns["disid"].ToString();

            DropDownList1.DataBind();
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.TextBox3.Text = this.DropDownList1.SelectedValue.ToString();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        cmd.Connection = conn;
        cmd.CommandText = "";
        string insert = "insert into District(DisName,DisID) values ('" + this.TextBox1.Text + "','" + this.TextBox2.Text + "')";
        cmd.CommandText = insert;
        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
            Label1.Text = "录入成功！";
        }
        catch
        {
            Label1.Text = "录入失败，请再次输入正确的信息！";
        }
        finally
        {
            conn.Close();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string update = "update District set DisID='" + this.TextBox2.Text + "',";
        update = update + "DisName=N'" + this.TextBox1.Text +"'" + "where DisID='" + this.TextBox3.Text +"'";
        cmd.Connection = conn;
        cmd.CommandText = "";
        cmd.CommandText = update;
        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
            Label1.Text = "修改成功！";
        }
        catch
        {
            Label1.Text = "修改失败，请重新修改！";
        }
        finally
        {
            conn.Close();
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        string delete = "delete from District where DisID='" + this.TextBox3.Text + "'";
        cmd.Connection = conn;
        cmd.CommandText = "";
        cmd.CommandText = delete;
        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
            Label1.Text = "删除成功！";
        }
        catch
        {
            Label1.Text = "删除失败，请确定有该信息后再重试！";
        }
        finally
        {
            conn.Close();
        }
    }
    protected void DropDownList1_PreRender(object sender, EventArgs e)
    {
        this.TextBox3.Text = this.DropDownList1.SelectedValue.ToString();
    }
}
