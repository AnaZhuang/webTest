# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Simple::Application.config.secret_token = '46fdd8b33d52bae3dd656ac4ae84e0139a4197925e17d58958ce3546a2fbb9c01902ab419a81b999ea1bf53872d515c719e6a9f4ca02d388728b64d373d85ffe'
