var http = require('http');

var server = http.createServer(function(req, res){
	res.writeHead(200);
        if(req.method == "HEAD"){
            res.end();
        }else{
            res.end('Hello http in NodeJS!');
        }
});

server.listen(process.argv[2]);
