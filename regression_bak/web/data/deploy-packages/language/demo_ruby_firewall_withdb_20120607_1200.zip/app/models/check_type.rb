class CheckType < ActiveRecord::Base
end
