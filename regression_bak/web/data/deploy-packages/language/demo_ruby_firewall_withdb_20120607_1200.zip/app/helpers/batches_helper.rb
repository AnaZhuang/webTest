module BatchesHelper
end
