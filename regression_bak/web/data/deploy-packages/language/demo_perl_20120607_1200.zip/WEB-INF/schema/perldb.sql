CREATE TABLE  `account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Account id, one application in our cloud associated with one unique account id.',
  `oaid` char(19) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'xxxx-xxxx-xxxx-xxxx' COMMENT 'Application id in OneCloud system.',
  `user_id` int(10) unsigned NOT NULL COMMENT 'User id, reference to User table id column.',
  `appname` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'Application name in OneCloud system.',
  `status` char(1) NOT NULL DEFAULT '0' COMMENT 'Status of application.(0:normal 1:delete 2:stop)',
  `creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data time of creatation this account.',
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Last update time.',
  `issettle` char(1) NOT NULL DEFAULT '0' COMMENT 'Whether compute over for this account consumption. 0:not yet 1:yes 2:processing',
  `stoptype` char(1) NOT NULL DEFAULT '0' COMMENT 'Type of causing stoping web application.(0:not stop 1:caused by arrear  2:caused by over free maximum amount )',
  `data_retention_date` date DEFAULT NULL COMMENT 'The last data retention date when web application stopped.',
  `isfree` char(1) NOT NULL DEFAULT '0' COMMENT 'If in free time.(0:no 1:yes)',
  PRIMARY KEY (`id`),
  KEY `unique_index` (`oaid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Billing account table';
insert into account (1,'212121',11,'www','0',now(),now(),'0','0',now(),'0');