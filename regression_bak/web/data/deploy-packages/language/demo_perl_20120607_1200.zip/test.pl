#!/user/bin/perl -w 
 
#HTTP HEADER
print "Content-type: text/html \n\n"; 
 
print "hello perl"; 
 