#!/user/bin/perl -w 
use DBI;
use Ocean;
#HTTP HEADER
print "Content-type: text/html \n\n"; 
 
print "$Ocean::OCE_MYSQL_DB"; 
#my $host = "$Ocean::OCE_MYSQL_HOST:$Ocean::$OCE_MYSQL_PORT";
#my $database = "$Ocean::OCE_MYSQL_DB";  
#my $user = "$Ocean::OCE_MYSQL_USER"; 
#my $pwd ="$Ocean::OCE_MYSQL_PWD";
#my $mydb = DBI->connect("DBI:mysql:$database:$host",$user, $pwd );
my $mydb = Ocean::connect();
my $mypre =$mydb->prepare("select * from account");
$mypre -> execute();
  print  "<table border='1'>";
  print  "<tr><th>id</th><th>oaid</th></tr>";
while(my $ref = $mypre->fetchrow_hashref()){
    print " <tr><td>id: $ref->{'id'}</td><td> oaid: $ref->{'oaid'}</td></tr>";

} 
  print  "</table>";
$mydb->disconnect();