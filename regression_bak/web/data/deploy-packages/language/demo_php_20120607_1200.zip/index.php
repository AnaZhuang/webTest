<?php require_once('inc/header.php') ?>





<h1>PHP Demo</h1>






<?php require_once('inc/footer.php') ?>
