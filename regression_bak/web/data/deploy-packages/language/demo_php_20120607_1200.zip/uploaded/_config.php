<?php
define('DB_HOST', '192.168.1.5:5505');
define('DB_USER', 'root');
define('DB_PWD', 'engine2ocean');
define('DB_NAME_DEFAULT', 'php_demo');
