<?php require_once('inc/header.php') ?>


<fieldset>
	<legend>Setting</legend>
	<table>
		<tr>
			<td>save_handler(ini):</td>
			<td><?php echo ini_get("session.save_handler") ?></td>
		</tr>
                <tr>
                        <td>save_path(ini):</td>
                        <td><?php echo ini_get("session.save_path") ?></td>
                </tr>
                <tr>
                        <td>save_path:</td>
                        <td><?php echo session_save_path() ?></td>
                </tr>
	</table>
</fieldset>

<?php
session_start();

$key = 'session_key_test';
$value = 'session_value_test';

if(!isset($_SESSION[$key])){
	echo "session '{$key}' not set";
	$_SESSION[$key] = $value;
}else{
	echo "session '{$key}' value is '{$_SESSION[$key]}'";
}
?>


<?php require_once('inc/footer.php') ?>
