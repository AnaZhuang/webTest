<html>
<head>
	<title>PHP Demo - OneCloud Technologies</title>
</head>
<body>

<?php
// get demo list
$arrFileNames = scandir('./');
?>

<div>
	<a href="index.php">Home</a>
<?php
foreach($arrFileNames as $demoFileName){
	// filter demo files
	$matches = array();
	if(!preg_match('/^demo_([\w]+)\.php$/', $demoFileName, $matches))
		continue;

	// demo name
	$demoName = ucfirst($matches[1]);
?>
	<a href="<?php echo $demoFileName ?>"><?php echo $demoName ?></a>
<?php
}
?>
</div>
