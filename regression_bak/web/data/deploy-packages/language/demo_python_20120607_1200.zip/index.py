#!/home/clouder/vs/program/language/python/python2_7_3/bin/python
from mod_python import apache
def handler(req):
        req.write("hello world!big guy!")
        return apache.OK
