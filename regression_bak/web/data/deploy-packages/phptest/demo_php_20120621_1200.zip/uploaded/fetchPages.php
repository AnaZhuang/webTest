<?php
//var_dump(dirname(__FILE__));
//  $content=<<<EOT
//  <li id="paas" name="paas" >
//<a href="/">PaaS简介</a>
//
//</li>
//<li id="pispower" name="pispower" >
//<a href="/solution/Pispower.html">Pispower</a>
//</li>
//<li id="vocchio" name="vocchio" >
//<a href="#">Vocchio</a>
//</li>
//<li id="private_cloud" name="private_cloud" >
//<a href='/solution/private_cloud.html'>私有云</a>
//</li>
//<li id="why_OneCloud" name="why_OneCloud" >
//<a href="/solution/why_OneCloud.png">为何选择亦云</a>
//</li>
//
//</ul>
//</li>
//<li id="case_study" name="case_study" class="suc">
//EOT;
//  var_dump(getChildPagesUrl($content));
//  exit;

$host = 'http://localhost:8080';
$filename = 'index.html';
$homePageUrl = $host . '/';
$arrWrittenFiles = array('/' => $homePageUrl);
$fetchedCount = 0;

fetchPage($filename, $homePageUrl);

echo "<br/> {$fetchedCount} pages fetched successfully!";

function fetchPage($filename, $url) {
  global $host, $arrWrittenFiles, $fetchedCount;
  
  if (!array_key_exists($url, $arrWrittenFiles)) {
    // get content
    $content = file_get_contents($url);

    // correct filename
    $filename = dirname(__FILE__) . '/' . trim($filename, '/');
    
    // check dir
    $dir = dirname($filename);
    if(!is_dir($dir)){
      mkdir($dir);
    }
    
    // write content
    $fh = fopen($filename, 'w+');
    fwrite($fh, $content);
    fclose($fh);
    $arrWrittenFiles[$url] = $filename;
    $fetchedCount++;
    echo "'$filename' fetched <br/> ";
    
    // fetch children
    if($childPagesUrl = getChildPagesUrl($content)){
      foreach($childPagesUrl as $childUrl => $filename){
        fetchPage($childUrl, $host . $childUrl);
      }
    }
  }
}

function getChildPagesUrl($content) {
  // get children
  $arrMatches = array();
  if (preg_match_all("/href\=['|\"]([^'|\"|#]+\.html)/", $content, $arrMatches)) {
    $arrResult = array();
    foreach($arrMatches[1] as  $url){
      $filename = substr($url, strrpos($url, '/') + 1);
      $arrResult[$url] = $filename;
    }
    return $arrResult;
  }
}

