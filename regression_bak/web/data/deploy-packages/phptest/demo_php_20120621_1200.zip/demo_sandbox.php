<?php require_once('inc/header.php') ?>
<h1>PHP Demo - Sandbox</h1>

<fieldset>
        <legend>File access monitoring</legend>
<?php

function myEcho($str = '', $bold = false){	
	if($bold){
		$str = '<b>'.$str.'</b>';
	}
	echo $str . '<br/>';
}

function tryChangeDir($dir){
?>
	<fieldset>
		<legend>File access: <?php echo $dir ?></legend>
<?php
	myEcho('Current directory:', true);
	myEcho(getcwd());
	myEcho();
	if(chdir($dir)){
		#myEcho('Sandbox is NOT working for file access monitoring!!!', true);
		#myEcho();
		myEcho('Directory changed to "' . $dir . '" !!!', true);
		myEcho('Current directory:', true);
		myEcho(getcwd());
		myEcho('Directory content:', true);
		$arrFiles = scandir($dir);
		if($arrFiles){
			foreach($arrFiles as $file){
				myEcho($file);
			}
		}
	}else{
		myEcho('Failed to change directory to "' . $dir . '".');
	}
?>
	</fieldset>
<?php
}

$dir = getcwd();

do{
	tryChangeDir($dir);
	$dir = substr($dir, 0, strrpos($dir, '/'));
}while($dir);

// root
tryChangeDir('/');
?>
</fieldset>

<fieldset>
	<legend>Socket monitoring</legend>
	*Note: Please provide correct configuration in "_config.php".<br/>
	<a href="demo_mysql.php">Check MySQL conntection</a>
</fieldset>

