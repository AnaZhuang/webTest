<?php require_once('inc/header.php') ?>
<?php
/*$arrUrls = array('http://localhost:8080', 'localhost:8080', 'https://localhost:8080');
foreach($arrUrls as $url){
	echo $url . ':<br/>';
	echo getCorrectUrl($url);
	echo '<br/>';	
}
exit;*/

function getCorrectUrl($url){
	$pattern = '/([^:]*:\/\/)?(.+)/';
	$matches = null;
	if(preg_match($pattern, $url, $matches)){       
                $protocol = $matches[1] ? $matches[1] : 'http://';
                $host = $matches[2];
                return $protocol . $host;
        }
	return null;
}

function getContent($url, &$error){
	$content = '';

	$ch = curl_init($url);

	//curl_setopt($ch, CURLOPT_FILE, $fp);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

	$content = curl_exec($ch);
	if(false === $content){
		$error = curl_error($ch);
	}
	curl_close($ch);
	return $content;
}

$isPostback = isset($_POST['url']);
$url = '';
$error = '';
if($isPostback){
	$url = getCorrectUrl($_POST['url']);
	if(!$url){
		$error = 'Invalid url detected!';
	}
	$content = getContent($url, $error);
}
?>
<fieldset>
	<legend>Get content</legend>
	<h5>Url: </h5>
	<form action="" method="POST">
	<input type="text" name="url" value="<?php echo $url ?>" /><br/>
	<input type="submit" value="Get Content" />
	</form>
	<?php echo $error ? $error . '<br/>' : '' ?>
	<?php if($isPostback && !$error){ ?>
	<h5>Result for <?php echo $url ?>: </h5>
	<textarea cols="100" rows="20">
	<?php echo $content; ?>
	</textarea>
	<?php } ?>
</fieldset>
<?php require_once('inc/footer.php') ?>
