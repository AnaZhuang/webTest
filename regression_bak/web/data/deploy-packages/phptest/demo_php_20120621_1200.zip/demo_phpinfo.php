<?php require_once('inc/header.php') ?>
<?php
phpinfo();
?>
<?php require_once('inc/footer.php') ?>
